
public class FindingNameRun {
	public static void main(String[] args) {
		String[] title = new String[4];
		title[0] = "Mr.";
		title[1] = "Mrs.";
		title[2] = "Boy";
		title[3] = "Girl";
		
		String[] name = new String[5];
		name[0] = "Harry";
		name[1] = "Ron";
		name[2] = "Hermione";
		name[3] = "Voldermort";
		name[4] = "Dumbledore";
		
		String[] job = new String[4];
		job[0] = "Farmer";
		job[1] = "Wizard";
		job[2] = "Doctor";
		job[3] = "Orphan";
		
		int[] age = new int[4];
		age[0] = 14;
		age[1] = 16;
		age[2] = 54;
		age[3] = 85;
		
		System.out.println("Im "+name[0]+" , a "+job[3]+
							" Im a "+title[2]+" , "+age[1]);
	}
}
