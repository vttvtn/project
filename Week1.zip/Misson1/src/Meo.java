
public class Meo extends ThuVat {

	public Meo(String ten, String mauLong, String loai, int canNang) {
		super(ten, mauLong, loai, canNang);
	}
	
	public String duoi(){
		return "duoi gian";
	}

}
