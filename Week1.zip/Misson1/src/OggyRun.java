
public class OggyRun {

	public static void main(String[] args) {
		Meo oggy = new Meo("Oggy", "xanh", "meo", 3);
		System.out.println("Toi la "+oggy.ten+" ,toi la 1 com "+oggy.loai+
							" Toi co mau "+oggy.mauLong+"" +
									" ,cong viec cua toi la "+oggy.duoi());
		
		Meo jack = new Meo("Jack", "xanh la", "meo", 4);
		System.out.println("Toi la "+jack.ten+" ,toi la 1 com "+jack.loai+
							" Toi co mau "+jack.mauLong+"" +
									" ,cong viec cua toi la "+jack.duoi());
		
		int[] dsSo = new int[10];
		dsSo[0] = 1;
		dsSo[1] = 2;
		dsSo[2] = 3;
		
		System.out.println("Toa so 0 la "+ dsSo[0]);
		System.out.println("Toa so 1 la "+ dsSo[1]);
		System.out.println("Toa so 2 la "+ dsSo[2]);
		
		Meo[] dsMeo = new Meo[2];
		dsMeo[0] = oggy;
		dsMeo[1] = jack;
		System.out.println("Con meo 0 la "+ dsMeo[0].ten);
		System.out.println("Con meo 1 la "+ dsMeo[1].ten);
	}
	
}
