
public abstract class ThuVat {
	String ten;
	String mauLong;
	String loai;
	int canNang;
	
	public ThuVat(String ten, String mauLong, String loai, int canNang) {
		super();
		this.ten = ten;
		this.mauLong = mauLong;
		this.loai = loai;
		this.canNang = canNang;
	}
}
